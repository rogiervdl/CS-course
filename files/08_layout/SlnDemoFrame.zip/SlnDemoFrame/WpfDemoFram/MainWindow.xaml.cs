﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfDemoFram.Pages;

namespace WpfDemoFram
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
public partial class MainWindow : Window
{
    protected const string Username = "Stan";
    public MainWindow()
    {
        InitializeComponent();
        frmMain.Content = new HomePage(Username);
    }

    private void BtnHome_Click(object sender, RoutedEventArgs e)
    {
        frmMain.Content = new HomePage(Username);
    }

    private void BtnProducts_Click(object sender, RoutedEventArgs e)
    {
        frmMain.Content = new ProductsPage(Username);
    }

    private void BtnAbout_Click(object sender, RoutedEventArgs e)
    {
        frmMain.Content = new AboutPage(Username);
    }
}
}