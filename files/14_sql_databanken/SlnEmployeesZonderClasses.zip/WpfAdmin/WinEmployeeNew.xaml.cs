﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Windows;

namespace WpfAdmin
{
    /// <summary>
    /// Interaction logic for WinEmployeeNew.xaml
    /// </summary>
    public partial class WinEmployeeNew : Window
    {
        string connString = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
        public WinEmployeeNew()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Knop "annuleren" geklikt
        /// </summary>
        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            // sluit dit venster
            this.Close();
        }

        /// <summary>
        /// Knop "opslaan" geklikt
        /// </summary>
private void btnSave_Click(object sender, RoutedEventArgs e)
{
    // werknemer opslaan
    int employeeId;
    using (SqlConnection conn = new SqlConnection(connString))
    {
        conn.Open();
        SqlCommand comm = new SqlCommand(
            "INSERT INTO Employee(firstname,lastname,email,gender,birthdate,accesscode) output INSERTED.ID VALUES(@par1,@par2,@par3,@par4,@par5,@par6)", conn);
        comm.Parameters.AddWithValue("@par1", txtFirst.Text);
            comm.Parameters.AddWithValue("@par2", txtLast.Text);
        comm.Parameters.AddWithValue("@par3", txtEmail.Text);
        comm.Parameters.AddWithValue("@par4", rbnMale.IsChecked == true ? 1 : rbnFemale.IsChecked == true ? 2 : 0);
        comm.Parameters.AddWithValue("@par5", datBirth.SelectedDate);
        if (txtCode.Text == String.Empty)
        {
            comm.Parameters.AddWithValue("@par6", DBNull.Value);
        }
        else
        {
            comm.Parameters.AddWithValue("@par6", txtCode.Text);
        }
        employeeId = (int)comm.ExecuteScalar();
    }

    // herlaad hoofdvenster, en sluit dit venster
    ((MainWindow)Application.Current.MainWindow).ShowEmployees(employeeId);
    this.Close();
}
    }
}
