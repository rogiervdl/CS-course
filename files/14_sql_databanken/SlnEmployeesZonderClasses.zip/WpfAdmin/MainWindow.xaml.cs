﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace WpfAdmin
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // connectiestring nodig om te connecteren met de databank
        string connString = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;

        /// <summary>
        /// MainWindow constructor
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();

            // toon alle werknemers in de lijst
            ShowEmployees();
        }

        /// <summary>
        /// Vraag alle werknemers op in de databank, en toon in de lijst
        /// </summary>
        public void ShowEmployees(int? selectedId = null)
        {
            // wis lijst en labels
            lbxResults.Items.Clear();
            lblEmail.Content = "";
            lblGender.Content = "";
            lblBirthdate.Content = "";
            lblCode.Content = "";

            // laad alle werknemers in
            using (SqlConnection conn = new SqlConnection(connString))
            {
                // open connectie
                conn.Open();

                // voer SQL commando uit
                SqlCommand comm = new SqlCommand("SELECT id, firstname, lastname FROM Employee", conn);
                SqlDataReader reader = comm.ExecuteReader();

                // lees en verwerk resultaten
                while (reader.Read())
                {
                    int id = Convert.ToInt32(reader["id"]);
                    string firstname = Convert.ToString(reader["firstname"]);
                    string lastname = Convert.ToString(reader["lastname"]);
                    ListBoxItem item = new ListBoxItem();
                    item.Content = $"{id}: {firstname} {lastname}";
                    item.Tag = id;
                    item.IsSelected = selectedId == id;
                    lbxResults.Items.Add(item);
                }
            }
        }

        /// <summary>
        /// Knop "bewerken" geklikt
        /// </summary>
        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            ListBoxItem item = (ListBoxItem)lbxResults.SelectedItem;
            int employeeId = Convert.ToInt32(item.Tag);
            WinEmployeeEdit editWin = new WinEmployeeEdit(employeeId);
            editWin.Show();
        }

        /// <summary>
        /// Knop "nieuw..." geklikt
        /// </summary>
        private void BtnNew_Click(object sender, RoutedEventArgs e)
        {
            WinEmployeeNew newWin = new WinEmployeeNew();
            newWin.Show();
        }

        /// <summary>
        /// Knop "verwijder" geklikt
        /// </summary>
        private void BtnRemove_Click(object sender, RoutedEventArgs e)
        {
            // vraag id geselecteerde werknemer op
            ListBoxItem item = (ListBoxItem)lbxResults.SelectedItem;
            if (item == null) return;
            int employeeId = Convert.ToInt32(item.Tag);

            // vraag bevestiging
            MessageBoxResult result = MessageBox.Show($"Ben je zeker dat je deze werknemer wil verwijderen?", "Werknemer verwijderen", MessageBoxButton.YesNo);
            if (result != MessageBoxResult.Yes) return;

            // verwijder de werknemer
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                SqlCommand comm = new SqlCommand("DELETE FROM Employee WHERE ID = @parID", conn);
                comm.Parameters.AddWithValue("@parID", employeeId);
                comm.ExecuteNonQuery();
            }
            ShowEmployees();
        }

        /// <summary>
        /// Geselecteerd item in de lijst is veranderd
        /// </summary>
        private void LbxResults_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // stel button states in
            ListBoxItem item = (ListBoxItem)lbxResults.SelectedItem;
            btnEdit.IsEnabled = item != null;
            btnRemove.IsEnabled = item != null;
            if (item == null) return;

            // als een werknemer geselecteerd is, vraag details op
            int employeeId = Convert.ToInt32(item.Tag);
            using (SqlConnection conn = new SqlConnection(connString))
            {
                // open connectie
                conn.Open();

                // vraag details van de werknemer op
                SqlCommand comm = new SqlCommand("SELECT * FROM Employee WHERE ID = @parID", conn);
                comm.Parameters.AddWithValue("@parID", employeeId);
                SqlDataReader reader = comm.ExecuteReader();
                reader.Read();
                lblEmail.Content = Convert.ToString(reader["email"]);
                int gender = Convert.ToInt32(reader["gender"]);
                lblGender.Content = gender == 1 ? "man" : gender == 2 ? "vrouw" : "onbekend";
                lblBirthdate.Content = Convert.ToDateTime(reader["birthdate"]).ToShortDateString();
                lblCode.Content = reader["accesscode"] == DBNull.Value ? "-" : Convert.ToInt32(reader["accesscode"]).ToString();
            }
        }
    }
}
