﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Windows;

namespace WpfAdmin
{
    /// <summary>
    /// Interaction logic for WinEmployeeEdit.xaml
    /// </summary>
    public partial class WinEmployeeEdit : Window
    {
        int employeeId;
        string connString = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;

        public WinEmployeeEdit(int id)
        {
            InitializeComponent();
            employeeId = id;

            // laad werknemer
            using (SqlConnection conn = new SqlConnection(connString))
            {
                // open connectie
                conn.Open();

                // voer SQL query uit
                SqlCommand comm = new SqlCommand("SELECT * FROM Employee WHERE ID = @parID", conn);
                comm.Parameters.AddWithValue("@parID", employeeId);
                SqlDataReader reader = comm.ExecuteReader();

                // lees en verwerk resultaten
                reader.Read();
                txtFirst.Text = Convert.ToString(reader["firstname"]);
                txtLast.Text = Convert.ToString(reader["lastname"]);
                txtEmail.Text = Convert.ToString(reader["email"]);
                int gender = Convert.ToInt32(reader["gender"]);
                if (gender == 1) rbnMale.IsChecked = true;
                else if (gender == 2) rbnFemale.IsChecked = true;
                else rbnUnknown.IsChecked = true;
                datBirth.SelectedDate = Convert.ToDateTime(reader["birthdate"]);
                txtCode.Text = reader["accesscode"] == DBNull.Value ? "" : Convert.ToInt32(reader["accesscode"]).ToString();
            }
            
        }

        /// <summary>
        /// Knop "annuleren" geklikt
        /// </summary>
        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            // sluit dit venster
            this.Close();
        }

        /// <summary>
        /// Knop "opslaan" geklikt
        /// </summary>
        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            int id = employeeId;
            // werknemer opslaan
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();

                // STANDARD QUERY VERSION
                SqlCommand comm = new SqlCommand(
                    @"UPDATE Employee
                        SET firstname=@par1, lastname=@par2, email=@par3, gender=@par4, birthdate=@par5, accesscode=@par6 
                        WHERE ID = @parID"
                    , conn);
                comm.Parameters.AddWithValue("@par1", txtFirst.Text);
                comm.Parameters.AddWithValue("@par2", txtLast.Text);
                comm.Parameters.AddWithValue("@par3", txtEmail.Text);
                comm.Parameters.AddWithValue("@par4", rbnMale.IsChecked == true ? 1 : rbnFemale.IsChecked == true ? 2 : 0);
                comm.Parameters.AddWithValue("@par5", datBirth.SelectedDate);
                if (txtCode.Text == String.Empty)
                {
                    comm.Parameters.AddWithValue("@par6", DBNull.Value);
                }
                else {
                    comm.Parameters.AddWithValue("@par6", txtCode.Text);
                }
                comm.Parameters.AddWithValue("@parID", id);
                comm.ExecuteNonQuery();
            }

            // herlaad hoofdvenster, en sluit dit venster
            ((MainWindow)Application.Current.MainWindow).ShowEmployees(employeeId);
            this.Close();
        }
    }
}
