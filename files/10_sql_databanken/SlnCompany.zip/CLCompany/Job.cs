﻿using System;
using System.Configuration;
using System.Data.SqlClient;

namespace CLCompany
{
    public class Job
    {
        // properties
        public int Id { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime? EndDate { get; set; } = null;
        public string JobTitle { get; set; }
        public int EmployeeId { get; set; }
        public Employee Employee
        {
            get
            {
                return Employee.GetById(EmployeeId);
            }
        }

        // constructors
        public Job() { }

        public Job(SqlDataReader reader)
        {
            Id = Convert.ToInt32(reader["id"]);
            StartDate = Convert.ToDateTime(reader["startdate"]);
            EndDate = reader["enddate"] == DBNull.Value ? null : (DateTime?)Convert.ToDateTime(reader["enddate"]);
            JobTitle = Convert.ToString(reader["jobtitle"]);
            EmployeeId = Convert.ToInt32(reader["employee_id"]);
        }
    }
}
