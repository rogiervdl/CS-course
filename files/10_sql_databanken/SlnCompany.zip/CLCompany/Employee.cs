﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;

namespace CLCompany
{
    public enum GenderType { Onbekend, Man, Vrouw, Nvt = 9 }
    public class Employee
    {
        // variables
        private static string connString = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;

        // properties
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public GenderType Gender { get; set; }
        public DateTime BirthDate { get; set; }
        public int? AccessCode { get; set; }
        public int? BossId { get; set; } = null;
        public Employee Boss
        {
            get
            {
                return BossId == null ? null : Employee.GetById((int)BossId);
            }
        }
        public List<Job> Jobs
        {
            get
            {
                List<Job> jobs = new List<Job>();
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    // open connectie
                    conn.Open();

                    // voer SQL commando uit
                    SqlCommand comm = new SqlCommand("SELECT * FROM Job WHERE employee_id=@par1 ORDER BY startdate", conn);
                    comm.Parameters.AddWithValue("@par1", Id);
                    SqlDataReader reader = comm.ExecuteReader();

                    // lees en verwerk resultaten
                    while (reader.Read()) jobs.Add(new Job(reader));
                }
                return jobs;

            }
        }

        // constructors
        public Employee() { }

        public Employee(SqlDataReader reader)
        {
            Id = Convert.ToInt32(reader["id"]);
            FirstName = Convert.ToString(reader["firstname"]);
            LastName = Convert.ToString(reader["lastname"]);
            Email = Convert.ToString(reader["email"]);
            Gender = (GenderType)Convert.ToInt32(reader["gender"]);
            BirthDate = Convert.ToDateTime(reader["birthdate"]);
            AccessCode = reader["accesscode"] == DBNull.Value ? null : (int?)Convert.ToInt32(reader["accesscode"]);
            BossId = reader["boss_id"] == DBNull.Value ? null : (int?)Convert.ToInt32(reader["boss_id"]);
        }

        // methods
        public static List<Employee> GetAll()
        {
            List<Employee> emps = new List<Employee>();
            using (SqlConnection conn = new SqlConnection(connString))
            {
                // open connectie
                conn.Open();

                // voer SQL commando uit
                SqlCommand comm = new SqlCommand("SELECT * FROM Employee", conn);
                SqlDataReader reader = comm.ExecuteReader();

                // lees en verwerk resultaten
                while (reader.Read()) emps.Add(new Employee(reader));
            }
            return emps;
        }
        public static Employee GetById(int empId)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                // open connectie
                conn.Open();

                // voer SQL commando uit
                SqlCommand comm = new SqlCommand("SELECT * FROM Employee WHERE ID = @parID", conn);
                comm.Parameters.AddWithValue("@parID", empId);
                SqlDataReader reader = comm.ExecuteReader();

                // lees en verwerk resultaten
                if (!reader.Read()) return null;
                return new Employee(reader);
            }
        }
        public void DeleteFromDb()
        {
            // verwijder gerelateerde jobs
            // dit is niet goed: foreach (Job j in Jobs) j.DeleteFromDb();
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                SqlCommand comm = new SqlCommand("DELETE FROM Job WHERE employee_id = @parID", conn);
                comm.Parameters.AddWithValue("@parID", Id);
                comm.ExecuteNonQuery();
            }

            // zet eventuele ondergeschikten zonder baas    
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                SqlCommand comm = new SqlCommand("UPDATE Employee SET boss_id = @par1 WHERE boss_id=@parID", conn);
                comm.Parameters.AddWithValue("@par1", DBNull.Value);
                comm.Parameters.AddWithValue("@parID", Id);
                comm.ExecuteNonQuery();
            }

            // verwijder tenslotte de werknemer zelf
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                SqlCommand comm = new SqlCommand("DELETE FROM Employee WHERE ID = @parID", conn);
                comm.Parameters.AddWithValue("@parID", Id);
                comm.ExecuteNonQuery();
            }
        }

        public int InsertToDb()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                // open connectie
                conn.Open();

                // voer SQL commando uit
                SqlCommand comm = new SqlCommand(
                  "INSERT INTO Employee(firstname,lastname,email,gender,birthdate,accesscode,boss_id) output INSERTED.ID VALUES(@par1,@par2,@par3,@par4,@par5,@par6,@par7)", conn);
                comm.Parameters.AddWithValue("@par1", FirstName);
                comm.Parameters.AddWithValue("@par2", LastName);
                comm.Parameters.AddWithValue("@par3", Email);
                comm.Parameters.AddWithValue("@par4", Gender);
                comm.Parameters.AddWithValue("@par5", BirthDate);
                comm.Parameters.AddWithValue("@par6", AccessCode == null ? DBNull.Value: AccessCode);
                comm.Parameters.AddWithValue("@par7", BossId == null ? DBNull.Value : BossId);

                // return de id van het nieuwe record
                Id = (int)comm.ExecuteScalar();
                return Id;
            }
        }

        public void UpdateInDb()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                // open connectie
                conn.Open();

                // voer SQL commando uit
                SqlCommand comm = new SqlCommand(
                    @"UPDATE Employee
                        SET firstname=@par1,lastname=@par2,email=@par3,gender=@par4,birthdate=@par5,accesscode=@par6,boss_id=@par7 
                        WHERE ID = @parID"
                    , conn);
                comm.Parameters.AddWithValue("@par1", FirstName);
                comm.Parameters.AddWithValue("@par2", LastName);
                comm.Parameters.AddWithValue("@par3", Email);
                comm.Parameters.AddWithValue("@par4", Gender);
                comm.Parameters.AddWithValue("@par5", BirthDate);
                comm.Parameters.AddWithValue("@par6", AccessCode == null ? DBNull.Value : AccessCode);
                comm.Parameters.AddWithValue("@par7", BossId == null ? DBNull.Value : BossId);
                comm.Parameters.AddWithValue("@parID", Id);
                comm.ExecuteNonQuery();
            }

        }

        public override string ToString()
        {
            // implementeer eigen ToString invulling
            return $"{FirstName} {LastName}";
        }
    }
}
