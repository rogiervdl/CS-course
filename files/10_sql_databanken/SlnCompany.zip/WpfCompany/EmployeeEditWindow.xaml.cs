﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using CLCompany;

namespace WpfCompany
{
    /// <summary>
    /// Interaction logic for EmployeeEditWindow.xaml
    /// </summary>
    public partial class EmployeeEditWindow : Window
    {
        Employee employee;

        public EmployeeEditWindow(int id)
        {
            InitializeComponent();

            // vul werknemer gegevens in
            employee = Employee.GetById(id);
            txtFirst.Text = employee.FirstName;
            txtLast.Text = employee.LastName;
            txtEmail.Text = employee.Email;
            if (employee.Gender == GenderType.Man) rbnMale.IsChecked = true;
            else if (employee.Gender == GenderType.Vrouw) rbnFemale.IsChecked = true;
            else rbnUnknown.IsChecked = true;
            datBirth.SelectedDate = employee.BirthDate;
            txtCode.Text = employee.AccessCode.ToString();

            // toon een lijst van employees in de bazen combobox gesorteerd op achternaam
            List<Employee> allEmployees = Employee.GetAll();
            allEmployees.Sort((x, y) => x.LastName.CompareTo(y.LastName));
            foreach (Employee emp in allEmployees)
            {
                cmbBoss.Items.Add(new ComboBoxItem()
                {
                    Content = emp,
                    Tag = emp.Id,
                    IsSelected = employee.Boss != null && employee.Boss.Id == emp.Id
                });
            }
        }

        /// <summary>
        /// Knop "annuleren" geklikt
        /// </summary>
        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            // sluit dit venster
            this.Close();
        }

        /// <summary>
        /// Knop "opslaan" geklikt
        /// </summary>
        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            // pas gegevens aan
            employee.FirstName = txtFirst.Text;
            employee.LastName = txtLast.Text;
            employee.Email = txtEmail.Text;
            if (rbnMale.IsChecked == true) employee.Gender = GenderType.Man;
            else if (rbnFemale.IsChecked == true) employee.Gender = GenderType.Vrouw;
            else employee.Gender = GenderType.Onbekend;
            employee.BirthDate = Convert.ToDateTime(datBirth.SelectedDate);
            employee.AccessCode = txtCode.Text == String.Empty ? null : (int?)Convert.ToInt32(txtCode.Text);
            int selectedId = Convert.ToInt32(((ComboBoxItem)cmbBoss.SelectedItem).Tag);
            employee.BossId = selectedId == -1 ? null : (int?)selectedId;

            // sla op in database
            employee.UpdateInDb();

            // herlaad hoofdvenster, en sluit dit venster
            ((MainWindow)Application.Current.MainWindow).ShowEmployees(employee.Id);
            this.Close();
        }
    }
}
