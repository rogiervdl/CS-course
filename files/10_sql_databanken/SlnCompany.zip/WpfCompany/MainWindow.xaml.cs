﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using CLCompany;

namespace WpfCompany
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // connectiestring nodig om te connecteren met de databank
        string connString = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;

        /// <summary>
        /// MainWindow constructor
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();

            // toon alle werknemers in de lijst
            ShowEmployees();
        }

        /// <summary>
        /// Vraag alle werknemers op in de databank, en toon in de lijst
        /// </summary>
        public void ShowEmployees(int? selectedId = null)
        {
            // wis lijst en labels
            lbxResults.Items.Clear();
            lblEmail.Content = lblGender.Content = lblBirthdate.Content = lblCode.Content = lblBoss.Content = "";

            // laad alle werknemers in
            List<Employee> allEmployees = Employee.GetAll();
            foreach (Employee emp in allEmployees)
            {
                lbxResults.Items.Add(new ListBoxItem()
                {
                    Content = $"{emp.Id}: {emp.FirstName} {emp.LastName}",
                    Tag = emp.Id,
                    IsSelected = selectedId == emp.Id
                });
            }
        }

        /// <summary>
        /// Knop "bewerken" geklikt
        /// </summary>
        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            // open edit window voor geselecteerd item
            ListBoxItem item = (ListBoxItem)lbxResults.SelectedItem;
            int employeeId = Convert.ToInt32(item.Tag);
            EmployeeEditWindow editWin = new EmployeeEditWindow(employeeId);
            editWin.Show();
        }

        /// <summary>
        /// Knop "nieuw..." geklikt
        /// </summary>
        private void BtnNew_Click(object sender, RoutedEventArgs e)
        {
            // open new window 
            EmployeeNewWindow newWin = new EmployeeNewWindow();
            newWin.Show();
        }

        /// <summary>
        /// Knop "verwijder" geklikt
        /// </summary>
        private void BtnRemove_Click(object sender, RoutedEventArgs e)
        {
            // vraag id geselecteerde werknemer op
            ListBoxItem item = (ListBoxItem)lbxResults.SelectedItem;
            if (item == null) return;
            Employee employee = Employee.GetById(Convert.ToInt32(item.Tag));

            // vraag bevestiging
            MessageBoxResult result = MessageBox.Show($"Ben je zeker dat je werknemer {employee} wil verwijderen?", "Werknemer verwijderen", MessageBoxButton.YesNo);
            if (result != MessageBoxResult.Yes) return;

            // verwijder de werknemer
            employee.DeleteFromDb();

            // herlaad overzicht
            ShowEmployees();
        }

        /// <summary>
        /// Geselecteerd item in de lijst is veranderd
        /// </summary>
        private void LbxResults_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // vraag employee op en stel button states in
            ListBoxItem item = (ListBoxItem)lbxResults.SelectedItem;
            btnEdit.IsEnabled = item != null;
            btnRemove.IsEnabled = item != null;
            if (item == null) return;
            Employee employee = Employee.GetById(Convert.ToInt32(item.Tag));

            // toon details 
            lblEmail.Content = employee.Email;
            lblGender.Content = employee.Gender == GenderType.Man ? "man" : employee.Gender == GenderType.Vrouw ? "vrouw" : "onbekend";
            lblBirthdate.Content = employee.BirthDate.ToShortDateString();
            lblCode.Content = employee.AccessCode == null ? "-" : employee.AccessCode.ToString();
            lblBoss.Content = employee.Boss == null ? "-" : employee.Boss.ToString();
            List<string> jobTitles = employee.Jobs.Select(j => j.JobTitle).ToList<string>();
            txtJobs.Text = jobTitles.Count == 0 ? "geen opgegeven" : (string.Join(Environment.NewLine, jobTitles) + (employee.Jobs.LastOrDefault().EndDate == null ? "(huidig)" : " (gestopt)"));
        }
    }
}
