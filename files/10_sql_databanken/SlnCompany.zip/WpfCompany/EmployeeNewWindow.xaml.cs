﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using CLCompany;

namespace WpfCompany
{
    /// <summary>
    /// Interaction logic for EmployeeNewWindow.xaml
    /// </summary>
    public partial class EmployeeNewWindow : Window
    {
        public EmployeeNewWindow()
        {
            InitializeComponent();

            // toon een lijst van employees in de bazen combobox gesorteerd op achternaam
            List<Employee> allEmployees = Employee.GetAll();
            allEmployees.Sort((x, y) => x.LastName.CompareTo(y.LastName));
            foreach (Employee emp in allEmployees)
            {
                cmbBoss.Items.Add(new ComboBoxItem()
                {
                    Content = emp,
                    Tag = emp.Id
                });
            }
        }
        /// <summary>
        /// Knop "annuleren" geklikt
        /// </summary>
        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            // sluit dit venster
            this.Close();
        }

        /// <summary>
        /// Knop "opslaan" geklikt
        /// </summary>
        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            // werknemer opslaan
            int bossId = Convert.ToInt32(((ComboBoxItem)cmbBoss.SelectedItem).Tag);
            Employee employee = new Employee()
            {
                FirstName = txtFirst.Text,
                LastName = txtLast.Text,
                Email = txtEmail.Text,
                Gender = rbnMale.IsChecked == true ? GenderType.Man : rbnFemale.IsChecked == true ? GenderType.Vrouw : GenderType.Onbekend,
                BirthDate = (DateTime)datBirth.SelectedDate,
                AccessCode = txtCode.Text == String.Empty ? null : (int?)Convert.ToInt32(txtCode.Text),
                BossId = bossId == -1 ? null : (int?)bossId
            };
            employee.InsertToDb();

            // herlaad hoofdvenster, en sluit dit venster
            ((MainWindow)Application.Current.MainWindow).ShowEmployees(employee.Id);
            this.Close();
        }
    }
}
