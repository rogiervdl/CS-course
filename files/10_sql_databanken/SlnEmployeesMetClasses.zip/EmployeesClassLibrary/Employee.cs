﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;

namespace EmployeesClassLibrary
{
    public enum GenderType { Onbekend = 0, Man = 1, Vrouw = 2, Nvt = 9 }
    public class Employee
    {
        // variables
        private static string connString = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;

        // properties
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public GenderType Gender { get; set; }
        public DateTime BirthDate { get; set; }
        public int? AccessCode { get; set; }

        // constructors
        public Employee() { }

        public Employee(SqlDataReader reader)
        {
            Id = Convert.ToInt32(reader["id"]);
            FirstName = Convert.ToString(reader["firstname"]);
            LastName = Convert.ToString(reader["lastname"]);
            Email = Convert.ToString(reader["email"]);
            Gender = (GenderType)Convert.ToInt32(reader["gender"]);
            BirthDate = Convert.ToDateTime(reader["birthdate"]);
            AccessCode = reader["accesscode"] == DBNull.Value ? null : (int?)Convert.ToInt32(reader["accesscode"]);
        }

        // methods
        public static List<Employee> GetAll()
        {
            List<Employee> emps = new List<Employee>();
            using (SqlConnection conn = new SqlConnection(connString))
            {
                // open connectie
                conn.Open();

                // voer SQL commando uit
                SqlCommand comm = new SqlCommand("SELECT * FROM Employee", conn);
                SqlDataReader reader = comm.ExecuteReader();

                // lees en verwerk resultaten
                while (reader.Read()) emps.Add(new Employee(reader));
            }
            return emps;
        }
        public static Employee GetById(int empId)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                // open connectie
                conn.Open();

                // voer SQL commando uit
                SqlCommand comm = new SqlCommand("SELECT * FROM Employee WHERE ID = @parID", conn);
                comm.Parameters.AddWithValue("@parID", empId);
                SqlDataReader reader = comm.ExecuteReader();

                // lees en verwerk resultaten
                if (!reader.Read()) return null;
                return new Employee(reader);
            }
        }
        public void DeleteFromDb()
        {
            // verwijder de werknemer 
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                SqlCommand comm = new SqlCommand("DELETE FROM Employee WHERE ID = @parID", conn);
                comm.Parameters.AddWithValue("@parID", Id);
                comm.ExecuteNonQuery();
            }
        }

        public int InsertToDb()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                // open connectie
                conn.Open();

                // voer SQL commando uit
                SqlCommand comm = new SqlCommand(
                  "INSERT INTO Employee(firstname,lastname,email,gender,birthdate,accesscode) output INSERTED.ID VALUES(@par1,@par2,@par3,@par4,@par5,@par6)", conn);
                comm.Parameters.AddWithValue("@par1", FirstName);
                comm.Parameters.AddWithValue("@par2", LastName);
                comm.Parameters.AddWithValue("@par3", Email);
                comm.Parameters.AddWithValue("@par4", Gender);
                comm.Parameters.AddWithValue("@par5", BirthDate);
                comm.Parameters.AddWithValue("@par6", AccessCode == null ? DBNull.Value : AccessCode);

                // return de id van het nieuwe record
                Id = (int)comm.ExecuteScalar();
                return Id;
            }
        }

        public void UpdateInDb()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                // open connectie
                conn.Open();

                // voer SQL commando uit
                SqlCommand comm = new SqlCommand(
                    @"UPDATE Employee
                        SET firstname=@par1,lastname=@par2,email=@par3,gender=@par4,birthdate=@par5,accesscode=@par6 
                        WHERE ID = @parID"
                    , conn);
                comm.Parameters.AddWithValue("@par1", FirstName);
                comm.Parameters.AddWithValue("@par2", LastName);
                comm.Parameters.AddWithValue("@par3", Email);
                comm.Parameters.AddWithValue("@par4", Gender);
                comm.Parameters.AddWithValue("@par5", BirthDate);
                if (AccessCode == null)
                {
                    comm.Parameters.AddWithValue("@par6", DBNull.Value);
                }
                else
                {
                    comm.Parameters.AddWithValue("@par6", AccessCode);
                }
                comm.Parameters.AddWithValue("@parID", Id);
                comm.ExecuteNonQuery();
            }

        }

        public override string ToString()
        {
            // implementeer eigen ToString invulling
            return $"{FirstName} {LastName}";
        }
    }
}
