﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using EmployeesClassLibrary;

namespace WpfAdmin
{
    /// <summary>
    /// Interaction logic for WinEmployeeNew.xaml
    /// </summary>
    public partial class WinEmployeeNew : Window
    {
        public WinEmployeeNew()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Knop "annuleren" geklikt
        /// </summary>
        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            // sluit dit venster
            this.Close();
        }

        /// <summary>
        /// Knop "opslaan" geklikt
        /// </summary>
        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            // werknemer opslaan
            Employee employee = new Employee();
            employee.FirstName = txtFirst.Text;
            employee.LastName = txtLast.Text;
            employee.Email = txtEmail.Text;
            employee.Gender = rbnMale.IsChecked == true ? GenderType.Man : rbnFemale.IsChecked == true ? GenderType.Vrouw : GenderType.Onbekend;
            employee.BirthDate = (DateTime)datBirth.SelectedDate;
            employee.AccessCode = txtCode.Text == String.Empty ? null : (int?)Convert.ToInt32(txtCode.Text);
            employee.InsertToDb();

            // herlaad hoofdvenster, en sluit dit venster
            ((MainWindow)Application.Current.MainWindow).ShowEmployees(employee.Id);
            this.Close();
        }
    }
}
