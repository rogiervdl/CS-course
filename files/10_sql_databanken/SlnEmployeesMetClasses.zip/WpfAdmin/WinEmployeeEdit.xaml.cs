﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using EmployeesClassLibrary;

namespace WpfAdmin
{
    /// <summary>
    /// Interaction logic for WinEmployeeEdit.xaml
    /// </summary>
    public partial class WinEmployeeEdit : Window
    {
        Employee employee;

        public WinEmployeeEdit(int id)
        {
            InitializeComponent();

            // vul werknemer gegevens in
            employee = Employee.GetById(id);
            txtFirst.Text = employee.FirstName;
            txtLast.Text = employee.LastName;
            txtEmail.Text = employee.Email;
            if (employee.Gender == GenderType.Man) rbnMale.IsChecked = true;
            else if (employee.Gender == GenderType.Vrouw) rbnFemale.IsChecked = true;
            else rbnUnknown.IsChecked = true;
            datBirth.SelectedDate = employee.BirthDate;
            txtCode.Text = employee.AccessCode.ToString();
        }

        /// <summary>
        /// Knop "annuleren" geklikt
        /// </summary>
        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            // sluit dit venster
            this.Close();
        }

        /// <summary>
        /// Knop "opslaan" geklikt
        /// </summary>
        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            employee.FirstName = txtFirst.Text;
            employee.LastName = txtLast.Text;
            employee.Email = txtEmail.Text;
            if (rbnMale.IsChecked == true) employee.Gender = GenderType.Man;
            else if (rbnFemale.IsChecked == true) employee.Gender = GenderType.Vrouw;
            else employee.Gender = GenderType.Onbekend;
            employee.BirthDate = Convert.ToDateTime(datBirth.SelectedDate);
            employee.AccessCode = txtCode.Text == String.Empty ? null : (int?) Convert.ToInt32(txtCode.Text);
            employee.UpdateInDb();

            // herlaad hoofdvenster, en sluit dit venster
            ((MainWindow) Application.Current.MainWindow).ShowEmployees(employee.Id);
            this.Close();
        }
    }
}
