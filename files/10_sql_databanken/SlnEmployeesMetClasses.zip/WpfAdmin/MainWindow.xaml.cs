﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using EmployeesClassLibrary;

namespace WpfAdmin
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // connectiestring nodig om te connecteren met de databank
        string connString = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;

        /// <summary>
        /// MainWindow constructor
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();

            // toon alle werknemers in de lijst
            ShowEmployees();
        }

        /// <summary>
        /// Vraag alle werknemers op in de databank, en toon in de lijst
        /// </summary>
        public void ShowEmployees(int? selectedId = null)
        {
            // wis lijst en labels
            lbxResults.Items.Clear();
            lblEmail.Content = "";
            lblGender.Content = "";
            lblBirthdate.Content = "";
            lblCode.Content = "";

            // laad alle werknemers in
            List<Employee> allEmployees = Employee.GetAll();
            foreach (Employee emp in allEmployees) {
                ListBoxItem item = new ListBoxItem();
                item.Content = $"{emp.Id}: {emp.FirstName} {emp.LastName}";
                item.Tag = emp.Id;
                item.IsSelected = selectedId == emp.Id;
                lbxResults.Items.Add(item);
            }
        }

        /// <summary>
        /// Knop "bewerken" geklikt
        /// </summary>
        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            // open edit window voor geselecteerd item
            ListBoxItem item = (ListBoxItem)lbxResults.SelectedItem;
            int employeeId = Convert.ToInt32(item.Tag);
            WinEmployeeEdit editWin = new WinEmployeeEdit(employeeId);
            editWin.Show();
        }

        /// <summary>
        /// Knop "nieuw..." geklikt
        /// </summary>
        private void BtnNew_Click(object sender, RoutedEventArgs e)
        {
            // open new window 
            WinEmployeeNew newWin = new WinEmployeeNew();
            newWin.Show();
        }

        /// <summary>
        /// Knop "verwijder" geklikt
        /// </summary>
        private void BtnRemove_Click(object sender, RoutedEventArgs e)
        {
            // vraag id geselecteerde werknemer op
            ListBoxItem item = (ListBoxItem)lbxResults.SelectedItem;
            if (item == null) return;
            Employee employee = Employee.GetById(Convert.ToInt32(item.Tag));

            // vraag bevestiging
            MessageBoxResult result = MessageBox.Show($"Ben je zeker dat je werknemer {employee} wil verwijderen?", "Werknemer verwijderen", MessageBoxButton.YesNo);
            if (result != MessageBoxResult.Yes) return;

            // verwijder de werknemer
            employee.DeleteFromDb();

            // herlaad overzicht
            ShowEmployees();
        }

        /// <summary>
        /// Geselecteerd item in de lijst is veranderd
        /// </summary>
        private void LbxResults_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // vraag employee op en stel button states in
            ListBoxItem item = (ListBoxItem)lbxResults.SelectedItem;
            btnEdit.IsEnabled = item != null;
            btnRemove.IsEnabled = item != null;
            if (item == null) return;
            Employee employee = Employee.GetById(Convert.ToInt32(item.Tag));

            // toon details 
            lblEmail.Content = employee.Email;
            lblGender.Content = employee.Gender == GenderType.Man ? "man" : employee.Gender == GenderType.Vrouw ? "vrouw" : "onbekend";
            lblBirthdate.Content = employee.BirthDate.ToShortDateString();
            lblCode.Content = employee.AccessCode == null ? "-" : employee.AccessCode.ToString();
        }
    }
}
